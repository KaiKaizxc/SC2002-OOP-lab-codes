package Planes;


import java.util.Arrays;

public class Plane {


    PlaneSeat[] seat;
    int numEmptySeat;

    Plane() {
        this.numEmptySeat = 12;
        this.seat = new PlaneSeat[12];
        for (int i = 0; i < 12 ; i++) {
            this.seat[i] = new PlaneSeat(i + 1);

        }

    }

    public void sortSeats() {
        Arrays.sort(this.seat);
    }

    public void showNumEmptySeats() {
        System.out.println(this.numEmptySeat);
    }

    public void showEmptySeats() {
        // show the list of empty seats
        for (int i = 0; i < 12; i++) {
            if (!this.seat[i].isOccupied()) {
                int id = i + 1;
                System.out.println("SeatID " + id);
            }
        }
    }

    public void showAssignedSeat(boolean bySeatId) {
        // show the list of assigned seat with SEAT ID and CUSTOMER ID
        if (bySeatId) {
            for (int i = 0; i < 12; i++) {
                if (this.seat[i].isOccupied()) {
                    int id = i + 1;
                    int customerID = this.seat[i].getCustomerID();
                    System.out.println("SeatID "  + id + " assigned to CustomerID " + customerID);

                }


            }
        } else {
            // make a deep copy , sort it then out it
            PlaneSeat[] tempPlane = new PlaneSeat[12];
            for (int i = 0; i < 12; i++) {
                PlaneSeat currentPlaneSeat = this.seat[i];
                // what do I need to copy? the customer ID , and isOccupied or not
                PlaneSeat temp = new PlaneSeat(i + 1);
                if (currentPlaneSeat.isOccupied()) {
                    int CustomerID = currentPlaneSeat.getCustomerID();
                    temp.assign(CustomerID);
                }

                tempPlane[i] = temp;

            }

            Arrays.sort(tempPlane);

            for (int i = 0; i < 12; i++) {
                if (tempPlane[i].isOccupied()) {
                    int id = i + 1;
                    int customerID = tempPlane[i].getCustomerID();
                    System.out.println("SeatID "  + id + " assigned to CustomerID " + customerID);

                }


            }
        }

    }

    public void assignSeat(int seatId, int cust_id) {
        // the seats are 1-based indexing
        if (!this.seat[seatId - 1].isOccupied()) {
            this.seat[seatId - 1].assign(cust_id);
            this.numEmptySeat--;
            System.out.println("Seat Assigned!");

        } else {
            System.out.println("Seat already assigned to a customer.");
        }


    }

    public void unAssignSeat(int seatId) {
        if (this.seat[seatId - 1].isOccupied()) {
            this.numEmptySeat++;
        }
        this.seat[seatId - 1].unAssign();

        System.out.println("Seat Unassigned!");


    }





}
