package Planes;
import java.util.*;

public class PlaneApp {

    Plane myPlane;

    public PlaneApp() {
        this.myPlane = new Plane();

    }

    public void runProgram() {
        boolean shouldRun = true;
        while (shouldRun) {

            this.displayInstructions();
            System.out.print("Enter the number of your choice:");

            Scanner sc = new Scanner(System.in);
            int input = sc.nextInt();
            switch (input) {
                case 1:
                    this.myPlane.showNumEmptySeats();
                    break;

                case 2:
                    this.myPlane.showEmptySeats();

                    break;

                case 3:
                    this.myPlane.showAssignedSeat(true);
                    break;

                case 4:
                    this.myPlane.showAssignedSeat(false);
                    break;

                case 5:
                    // assign a customer to a seat id here
                    System.out.println("Assigning Seat...");
                    System.out.print("Please enter SeatID:");
                    Scanner scID = new Scanner(System.in);
                    int seatID = scID.nextInt();
                    System.out.print("Please enter Customer ID:");
                    Scanner cID = new Scanner(System.in);
                    int CustomerID = cID.nextInt();

                    this.myPlane.assignSeat(seatID, CustomerID);
                    break;

                case 6:

                    // remove a seat assignment here
                    System.out.print("Enter SeatID to unassign customer from:");
                    Scanner unassignSC = new Scanner(System.in);
                    int unassignID = unassignSC.nextInt();
                    this.myPlane.unAssignSeat(unassignID);
                    break;

                case 7:
                    shouldRun = false;
                    break;
            }
        }
    }

    public void displayInstructions() {
        System.out.println("(1) Show number of empty seats");
        System.out.println("(2) Show the list of empty seats");
        System.out.println("(3) Show the list of seat assignments by seat ID");
        System.out.println("(4) Show the list of seat assignments by customer ID");
        System.out.println("(5) Assign a customer to a seat");
        System.out.println("(6) Remove a seat assignment");
        System.out.println("(7) Exit");
    }




}
