import Planes.*;


public class Main {
    public static void main(String[] args) {
        PlaneApp plane = new PlaneApp();
        plane.runProgram();

    }
}